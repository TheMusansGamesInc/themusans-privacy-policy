# The Musans Games Inc – Privacy Policy Site

This folder contains a **ready‑to‑host** `index.html` privacy policy for **Kids Preschool Learning Games – ABC, 123, Colors & Shapes**.

## How to Host (GitHub Pages)
1. Create a new public repo (e.g., `privacy-policy`).
2. Add this `index.html` file to the repo root.
3. In **Settings → Pages**, set **Source: Deploy from a branch**, Branch: `main` (root).
4. Your policy will be live at: `https://&lt;your-username&gt;.github.io/privacy-policy/`

## How to Host (Netlify Drop)
1. Visit `https://app.netlify.com/drop`.
2. Drag & drop this folder – you'll get a public URL instantly.

## How to Host (Any Static Host)
Upload `index.html` and share the public link in **Google Play Console → App Content → Privacy Policy**.
